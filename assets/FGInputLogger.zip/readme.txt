1- install SLimDX in dependecies folder for your respective system dependecies
2 - run FGInputLogger.exe
3 - Configure and enjoy